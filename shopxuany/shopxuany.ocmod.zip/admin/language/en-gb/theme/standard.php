<?php
// Heading
$_['heading_title'] = 'Shop Xuan Y Theme';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the Shop Xuan Y theme!';
$_['text_edit'] = 'Edit Shop Xuan Y Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Shop Xuan Y theme!';
